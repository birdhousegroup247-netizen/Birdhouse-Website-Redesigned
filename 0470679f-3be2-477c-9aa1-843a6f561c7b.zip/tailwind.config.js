export default {
  content: [
  './index.html',
  './src/**/*.{js,ts,jsx,tsx}'
],
  theme: {
    extend: {
      colors: {
        brand: {
          green: '#0F9D58',
          greenLight: '#E7F5EE',
          greenDark: '#0B7A44',
        },
        surface: {
          primary: '#FFFFFF',
          secondary: '#F7F9F8',
          tertiary: '#F0F2F1',
        },
        text: {
          primary: '#1A1A1A',
          secondary: '#5F6368',
          tertiary: '#8C9096',
        }
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
        display: ['Inter', 'sans-serif'],
      },
      maxWidth: {
        'desktop': '1440px',
      },
      boxShadow: {
        'glass': '0 8px 32px 0 rgba(0, 0, 0, 0.04)',
        'glass-hover': '0 12px 48px 0 rgba(0, 0, 0, 0.08)',
        'soft': '0 4px 24px 0 rgba(0, 0, 0, 0.03)',
        'soft-hover': '0 12px 32px 0 rgba(0, 0, 0, 0.06)',
      }
    },
  },
  plugins: [],
}