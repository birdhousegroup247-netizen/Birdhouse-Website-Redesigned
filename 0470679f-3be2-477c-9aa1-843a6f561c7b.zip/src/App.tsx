import React from 'react';
import { GlassNav } from './components/layout/GlassNav';
import { Footer } from './components/layout/Footer';
import { Hero } from './components/hero/Hero';
import { FeaturedWork } from './components/sections/FeaturedWork';
import { Services } from './components/sections/Services';
import { Process } from './components/sections/Process';
import { Testimonials } from './components/sections/Testimonials';
import { FinalCTA } from './components/sections/FinalCTA';
export function App() {
  return (
    <div className="min-h-screen bg-surface-primary selection:bg-brand-green selection:text-white">
      <GlassNav />

      <main>
        <Hero />
        <FeaturedWork />
        <Services />
        <Process />
        <Testimonials />
        <FinalCTA />
      </main>

      <Footer />
    </div>);

}