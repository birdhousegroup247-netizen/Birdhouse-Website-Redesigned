import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Search } from 'lucide-react';
import { Button } from '../ui/Button';
const NAV_LINKS = ['Work', 'Studio', 'Services', 'Insights'];
export function GlassNav() {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  return (
    <motion.nav
      initial={{
        y: -100
      }}
      animate={{
        y: 0
      }}
      transition={{
        duration: 0.8,
        ease: [0.16, 1, 0.3, 1]
      }}
      className={`fixed top-0 w-full z-50 transition-all duration-500 ${scrolled ? 'py-4' : 'py-8'}`}>
      
      <div className="max-w-desktop mx-auto px-12">
        <div
          className={`flex items-center justify-between rounded-2xl px-8 py-4 transition-all duration-500 ${scrolled ? 'glass-panel' : 'bg-transparent'}`}>
          
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-brand-green flex items-center justify-center">
              <div className="w-3 h-3 bg-white rounded-sm" />
            </div>
            <span className="font-bold text-xl tracking-tight">Birdhouse</span>
          </div>

          <div className="flex items-center gap-10 text-sm font-medium text-text-secondary">
            {NAV_LINKS.map((link, i) =>
            <a
              key={link}
              href="#"
              className={`transition-colors ${i === 0 ? 'text-text-primary' : 'hover:text-text-primary'}`}>
              
                {link}
              </a>
            )}
          </div>

          <div className="flex items-center gap-6">
            <button
              aria-label="Search"
              className="text-text-secondary hover:text-text-primary transition-colors">
              
              <Search className="w-5 h-5" />
            </button>
            <Button variant="primary" size="sm">
              Start a Project
            </Button>
          </div>
        </div>
      </div>
    </motion.nav>);

}