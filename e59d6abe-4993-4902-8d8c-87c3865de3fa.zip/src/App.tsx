import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { WorkPage } from './pages/WorkPage';
import { ServicesPage } from './pages/ServicesPage';
export function App() {
  return (
    <BrowserRouter>
      <div className="min-w-[1200px] max-w-[1600px] mx-auto bg-[#FAFAFA] min-h-screen font-sans relative overflow-x-hidden">
        <Navbar />
        <Routes>
          <Route path="/" element={<WorkPage />} />
          <Route path="/services" element={<ServicesPage />} />
        </Routes>
        <Footer />
      </div>
    </BrowserRouter>);

}