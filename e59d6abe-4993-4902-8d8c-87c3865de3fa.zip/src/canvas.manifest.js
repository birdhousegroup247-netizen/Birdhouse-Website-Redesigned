export const manifest = {
  screens: {
    scr_960j6q: { name: "Hero", route: "/", position: { "x": 160, "y": 220 } },
    scr_9an1jp: { name: "PayFlow Pro", route: "/#work", position: { "x": 1560, "y": 220 } },
    scr_pwkoyt: { name: "CTA", route: "/#cta", position: { "x": 2960, "y": 220 } },
    scr_es0xzj: { name: "Services", route: "/services", position: { "x": 160, "y": 2200 } }
  },
  sections: {
    sec_r1edmj: { name: "Landing Page", x: 0, y: 0, width: 4320, height: 1180 },
    sec_goykjv: { name: "Services Page", x: 0, y: 1980, width: 1520, height: 1180 }
  },
  layers: [
  { kind: "section", id: "sec_r1edmj", children: [
    { kind: "screen", id: "scr_960j6q" },
    { kind: "screen", id: "scr_9an1jp" },
    { kind: "screen", id: "scr_pwkoyt" }]
  },
  { kind: "section", id: "sec_goykjv", children: [
    { kind: "screen", id: "scr_es0xzj" }]
  }]

};