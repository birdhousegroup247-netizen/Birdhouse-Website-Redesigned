import React from 'react';
export const Footer = () => {
  return (
    <footer className="bg-white border-t border-surface-200 pt-20 pb-10 px-8">
      <div className="max-w-[1600px] mx-auto">
        <div className="grid grid-cols-12 gap-12 mb-16">
          <div className="col-span-4">
            <div className="flex items-center gap-2 mb-6">
              <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center">
                <div className="w-3 h-3 bg-white rounded-full"></div>
              </div>
              <span className="font-bold text-xl tracking-tight text-surface-900">
                Birdhouse Group
              </span>
            </div>
            <p className="text-surface-500 leading-relaxed max-w-sm">
              A premium digital product agency crafting intuitive experiences
              and scalable software for ambitious brands.
            </p>
          </div>

          <div className="col-span-2 col-start-7">
            <h4 className="font-bold text-surface-900 mb-6">Work</h4>
            <ul className="space-y-4">
              <li>
                <a
                  href="#"
                  className="text-surface-500 hover:text-emerald-500 transition-colors">
                  
                  Case Studies
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-surface-500 hover:text-emerald-500 transition-colors">
                  
                  Open Source
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-surface-500 hover:text-emerald-500 transition-colors">
                  
                  Playground
                </a>
              </li>
            </ul>
          </div>

          <div className="col-span-2">
            <h4 className="font-bold text-surface-900 mb-6">Company</h4>
            <ul className="space-y-4">
              <li>
                <a
                  href="#"
                  className="text-surface-500 hover:text-emerald-500 transition-colors">
                  
                  About Us
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-surface-500 hover:text-emerald-500 transition-colors">
                  
                  Careers
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-surface-500 hover:text-emerald-500 transition-colors">
                  
                  Contact
                </a>
              </li>
            </ul>
          </div>

          <div className="col-span-2">
            <h4 className="font-bold text-surface-900 mb-6">Social</h4>
            <ul className="space-y-4">
              <li>
                <a
                  href="#"
                  className="text-surface-500 hover:text-emerald-500 transition-colors">
                  
                  Twitter
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-surface-500 hover:text-emerald-500 transition-colors">
                  
                  LinkedIn
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-surface-500 hover:text-emerald-500 transition-colors">
                  
                  Dribbble
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-center pt-8 border-t border-surface-100 text-sm text-surface-400">
          <p>
            © {new Date().getFullYear()} Birdhouse Group. All rights reserved.
          </p>
          <div className="flex gap-6 mt-4 md:mt-0">
            <a href="#" className="hover:text-surface-900 transition-colors">
              Privacy Policy
            </a>
            <a href="#" className="hover:text-surface-900 transition-colors">
              Terms of Service
            </a>
          </div>
        </div>
      </div>
    </footer>);

};