import React from 'react';
import { motion } from 'framer-motion';
import { Link, useLocation } from 'react-router-dom';
export const Navbar = () => {
  const { pathname } = useLocation();
  const linkClass = (active: boolean) =>
  `text-sm font-medium transition-colors ${active ? 'text-emerald-500' : 'text-surface-500 hover:text-emerald-500'}`;
  return (
    <motion.nav
      initial={{
        y: -20,
        opacity: 0
      }}
      animate={{
        y: 0,
        opacity: 1
      }}
      transition={{
        duration: 0.8,
        ease: [0.16, 1, 0.3, 1]
      }}
      className="fixed top-0 left-0 right-0 z-50 px-8 py-6 flex justify-between items-center max-w-[1600px] mx-auto">
      
      <Link to="/" className="flex items-center gap-2">
        <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center">
          <div className="w-3 h-3 bg-white rounded-full"></div>
        </div>
        <span className="font-bold text-xl tracking-tight text-surface-900">
          Birdhouse Group
        </span>
      </Link>

      <div className="hidden md:flex items-center gap-8 glass-panel px-8 py-3 rounded-full">
        <Link to="/" className={linkClass(pathname === '/')}>
          Work
        </Link>
        <Link to="/services" className={linkClass(pathname === '/services')}>
          Services
        </Link>
        <a
          href="#about"
          className="text-sm font-medium text-surface-500 hover:text-emerald-500 transition-colors">
          
          About
        </a>
      </div>

      <button
        onClick={() =>
        document.getElementById('cta')?.scrollIntoView({
          behavior: 'smooth'
        })
        }
        className="bg-surface-900 text-white px-6 py-3 rounded-full text-sm font-semibold hover:bg-emerald-500 transition-all duration-300 shadow-sm hover:shadow-md">
        
        Start a Project
      </button>
    </motion.nav>);

};