import React from 'react';
import { ServicesHero } from '../components/ServicesHero';
import { ServicesList } from '../components/ServicesList';
import { ProcessSection } from '../components/ProcessSection';
import { CtaSection } from '../components/CtaSection';
export function ServicesPage() {
  return (
    <main className="pt-20">
      <ServicesHero />
      <ServicesList />
      <ProcessSection />
      <CtaSection />
    </main>);

}