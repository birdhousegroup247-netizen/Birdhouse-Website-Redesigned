import React from 'react';
import { Hero } from '../components/Hero';
import { ProjectOne } from '../components/ProjectOne';
import { ProjectTwo } from '../components/ProjectTwo';
import { ProjectThree } from '../components/ProjectThree';
import { CtaSection } from '../components/CtaSection';
export function WorkPage() {
  return (
    <main>
      <Hero />
      <ProjectOne />
      <ProjectTwo />
      <ProjectThree />
      <CtaSection />
    </main>);

}